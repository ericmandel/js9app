  /***********************************************
  * DHTML Window Widget- © Dynamic Drive (www.dynamicdrive.com)
  * This notice must stay intact for legal use.
  * Visit http://www.dynamicdrive.com/ for full source code
  ***********************************************/
